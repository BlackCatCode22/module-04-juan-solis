package JavaZooPractice;
public class Hyena extends Animal {
    private String laughType;
    public Hyena(String name, int age, String laughType) {
        super(name, age, "Hyena");
        this.laughType = laughType;
    }
    public String getLaughType() {
        return laughType;
    }
    public void setLaughType(String laughType) {
        this.laughType = laughType;
    }
}

