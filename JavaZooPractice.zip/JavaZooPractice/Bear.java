package JavaZooPractice;
public class Bear extends Animal {
    private String roarType;
    public Bear(String name, int age, String roarType) {
        super(name, age, "Bear");
        this.roarType = roarType;
    }
    public String getRoarType() {
        return roarType;
    }
    public void setRoarType(String roarType) {
        this.roarType = roarType;
    }
}
