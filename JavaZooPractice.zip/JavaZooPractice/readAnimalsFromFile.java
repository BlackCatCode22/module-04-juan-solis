package JavaZooPractice;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public void readAnimalsFromFile(String filePath) {
    try {
        File file = new File(filePath);
        Scanner scanner = new Scanner(file);

        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] details = line.split(",");
            String name = details[0];
            int age = Integer.parseInt(details[1]);
            String species = details[2];

            Animal animal = new Animal(name, age, species); // Assuming a constructor exists
            animals.add(animal);
            speciesCount.put(species, speciesCount.getOrDefault(species, 0) + 1);
        }
        scanner.close();
    } catch (FileNotFoundException e) {
        System.out.println("File not found: " + filePath);
    }
}
