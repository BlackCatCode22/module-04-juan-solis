package JavaZooPractice;

import java.io.FileWriter;
import java.io.IOException;

public void writeReportToFile(String filePath) {
    try {
        FileWriter writer = new FileWriter(filePath);

        for (Animal animal : animals) {
            writer.write(animal.getSpecies() + ": " + animal.getName() + ", Age: " + animal.getAge() + "\n");
        }
        writer.close();
    } catch (IOException e) {
        System.out.println("An error occurred while writing to the file: " + filePath);
    }
}
