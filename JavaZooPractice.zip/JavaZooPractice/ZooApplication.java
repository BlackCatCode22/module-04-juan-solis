package JavaZooPractice;

import java.util.ArrayList;
import java.util.HashMap;

public class ZooApplication {
    private ArrayList<Animal> animals = new ArrayList<>();
    private HashMap<String, Integer> speciesCount = new HashMap<>();

    public static void main(String[] args) {
        ZooApplication app = new ZooApplication();
        app.run();
    }

    public void run() {
        // Example function calls
        readAnimalsFromFile("arrivingAnimals.txt");
        writeReportToFile("newAnimals.txt");
    }

    private void readAnimalsFromFile(java.lang.String file) {
    }

    private void writeReportToFile(java.lang.String file) {
        
    }

    public void readAnimalsFromFile(String filePath) {
        // Implementation of file reading and populating data structures
    }

    public void writeReportToFile(String filePath) {
        // Implementation of file writing
    }
}